
/**
 *
 * @author seinc
 * @author ElBet0
 */
public class SisProg {


    /*
     * En teoría ya funcionan PAGO/DEUDA/FAMILIA/ALUMNO/VACANTES-AULA
     */
    public static void main(String[] args) {
        System.out.println("HELLOOOOOOO!!!!!!! :D");
    }
}
