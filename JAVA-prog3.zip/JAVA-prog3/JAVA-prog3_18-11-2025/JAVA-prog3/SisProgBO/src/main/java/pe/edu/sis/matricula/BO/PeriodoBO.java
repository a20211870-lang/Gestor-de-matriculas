/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pe.edu.sis.matricula.BO;

import pe.edu.sis.BO.IBaseBO;
import pe.edu.sis.model.matricula.PeriodoAcademico;

/**
 *
 * @author sdelr
 */
public interface PeriodoBO extends IBaseBO<PeriodoAcademico> {
    
}
