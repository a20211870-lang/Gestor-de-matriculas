package pe.edu.sis.usuario.dao;

import pe.edu.sis.dao.IDAO;
import pe.edu.sis.model.usuario.Cargo;

public interface CargoDAO extends IDAO<Cargo> {

}
