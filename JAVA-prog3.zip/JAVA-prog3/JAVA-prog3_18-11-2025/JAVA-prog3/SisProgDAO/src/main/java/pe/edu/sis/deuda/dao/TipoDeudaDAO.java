package pe.edu.sis.deuda.dao;

import pe.edu.sis.dao.IDAO;
import pe.edu.sis.model.deuda.TipoDeuda;

/**
 *
 * @author ElBet0
 */

public interface TipoDeudaDAO extends IDAO<TipoDeuda> {

}
